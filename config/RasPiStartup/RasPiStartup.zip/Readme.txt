https://wiki.gentoo.org/wiki//etc/local.d
